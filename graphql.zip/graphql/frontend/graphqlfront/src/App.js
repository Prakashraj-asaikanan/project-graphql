import React from 'react';
import './App.css';
import {
  BrowserRouter,
  Route, Switch, Redirect
} from 'react-router-dom'
import Auth from './pages/Auth';
import Booking from './pages/Bookings';
import Event from './pages/Events';
import MainNavigation from './component/MainNavigation';

function App() {
  return (
    <BrowserRouter>
      <MainNavigation />
      <main>
        <Switch>
          <Redirect from="/" to="/auth" exact />
          <Route path="/auth" component={Auth} />
          <Route path="/bookings" component={Booking} />
          <Route path="/events" component={Event} />
        </Switch>
      </main>

    </BrowserRouter>
  );
}

export default App;