import React,{Component} from 'react';

export default class Auth extends Component
{
    render(){
        return(
            <div>
                <h1>Authentication</h1>
            </div>
        );
    }
}