import React,{Component} from 'react';

export default class Bookings extends Component
{
    render(){
        return(
            <div>
                <h1>Bookings</h1>
            </div>
        );
    }
}