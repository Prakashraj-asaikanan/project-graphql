const express = require('express');
const bodyParser = require('body-parser');
const graphqlHTTP = require('express-graphql').graphqlHTTP;
const mongoose = require('mongoose');
const app = express();
const buildSchema = require('./graphql/schema/index.js')
const resolver = require('./graphql/resolver/index.js');
const isAuth = require('./middleware/auth');
console.log(isAuth);
app.use(bodyParser.json());

app.use(isAuth);
app.use('/api', graphqlHTTP({
    schema: buildSchema,
    rootValue: resolver,
    graphiql: true

}));

mongoose.connect("mongodb+srv://graphql:graphql123@cluster0.n8q1o.mongodb.net/events?retryWrites=true&w=majority", {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(res => {
        console.log('connected successfully');
        app.listen(3000);
    }).catch(err => {
        console.log(err, 'Error in Connection');
    });